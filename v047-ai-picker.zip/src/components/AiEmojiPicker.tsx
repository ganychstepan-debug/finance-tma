import { useState } from 'react'
import { haptic } from '@/lib/telegram'
import { suggestEmoji } from '@/lib/ai'
import { moderate, getCategoryList } from '@/lib/moderation'

interface Props {
  onPicked: (emoji: string) => void
  /** Текущее выбранное custom-эмодзи (показываем рядом если есть) */
  currentCustomEmoji?: string
}

/**
 * Интерактивное поле "Опиши иконку словами" + кнопка "ИИ подберёт".
 * Отправляет описание на /api/emoji, получает эмодзи, вызывает onPicked().
 *
 * Показывает состояния: idle / loading / success / error.
 */
export const AiEmojiPicker: React.FC<Props> = ({ onPicked, currentCustomEmoji }) => {
  const [description, setDescription] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [blocked, setBlocked] = useState<{ category: string } | null>(null)
  const [expanded, setExpanded] = useState(Boolean(currentCustomEmoji))

  const handleSuggest = async () => {
    const text = description.trim()
    if (!text || loading) return

    // Клиентская модерация — мгновенно, без запроса к серверу
    const modResult = moderate(text)
    if (!modResult.ok) {
      haptic.error()
      setBlocked({ category: modResult.category || 'запрещённое содержимое' })
      setError(null)
      return
    }

    haptic.light()
    setLoading(true)
    setError(null)
    setBlocked(null)
    try {
      const result = await suggestEmoji(text)
      onPicked(result.emoji)
      setDescription('')
    } catch (e) {
      const msg = (e as Error).message
      // Сервер мог вернуть 403 с модерацией — показываем аналогичное предупреждение
      if (msg.includes('запрещ') || msg.includes('BLOCKED')) {
        setBlocked({ category: 'запрещённое содержимое' })
      } else {
        setError(msg)
      }
      haptic.error()
    } finally {
      setLoading(false)
    }
  }

  // Если юзер начал редактировать текст — сбрасываем предупреждение о блокировке
  const handleDescChange = (v: string) => {
    setDescription(v)
    if (error) setError(null)
    if (blocked) setBlocked(null)
  }

  if (!expanded) {
    return (
      <button
        onClick={() => { haptic.light(); setExpanded(true) }}
        className="mt-3 w-full py-2 bg-transparent border-0 cursor-pointer"
        style={{ color: '#888', fontSize: 11 }}
      >
        ▾ Нет подходящей? ИИ подберёт
      </button>
    )
  }

  return (
    <div
      className="mt-3"
      style={{
        background: '#141414',
        border: '0.5px solid rgba(255,23,68,0.3)',
        borderRadius: 14,
        padding: 12,
      }}
    >
      <div className="flex items-center" style={{ gap: 8, marginBottom: 10 }}>
        <span style={{ fontSize: 13 }}>🤖</span>
        <span style={{ color: '#888', fontSize: 11 }}>ИИ-подбор иконки</span>
        {currentCustomEmoji && (
          <div className="ml-auto flex items-center" style={{ gap: 6 }}>
            <span style={{ color: '#666', fontSize: 9 }}>Текущее:</span>
            <span style={{ fontSize: 18 }}>{currentCustomEmoji}</span>
          </div>
        )}
      </div>
      <div className="flex" style={{ gap: 8 }}>
        <input
          type="text"
          placeholder="Например: коктейли на пляже"
          value={description}
          onChange={(e) => handleDescChange(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') handleSuggest() }}
          maxLength={100}
          disabled={loading}
          className="flex-1 disabled:opacity-50"
          style={{
            padding: '9px 11px',
            background: '#0a0a0a',
            border: blocked ? '0.5px solid #ff1744' : '0.5px solid #222',
            borderRadius: 10,
            color: '#fff',
            fontSize: 12,
            boxSizing: 'border-box',
          }}
        />
        <button
          onClick={handleSuggest}
          disabled={!description.trim() || loading || Boolean(blocked)}
          className="cursor-pointer border-0 active:scale-[0.98] transition-transform flex items-center justify-center"
          style={{
            padding: '9px 14px',
            background: description.trim() && !loading && !blocked ? '#ff1744' : '#1f1f1f',
            borderRadius: 10,
            color: description.trim() && !loading && !blocked ? '#fff' : '#555',
            fontSize: 12,
            fontWeight: 600,
            gap: 4,
            minWidth: 80,
          }}
        >
          {loading ? (
            <>
              <span className="ai-dot" />
              <span className="ai-dot" style={{ animationDelay: '0.15s' }} />
              <span className="ai-dot" style={{ animationDelay: '0.3s' }} />
            </>
          ) : (
            'Подобрать'
          )}
        </button>
      </div>

      {/* Блок предупреждения при блокировке */}
      {blocked && (
        <div
          className="mt-2"
          style={{
            background: 'rgba(255,23,68,0.08)',
            border: '0.5px solid rgba(255,23,68,0.4)',
            borderRadius: 12,
            padding: 11,
          }}
        >
          <div className="flex items-center" style={{ gap: 6, marginBottom: 6 }}>
            <span style={{ fontSize: 11 }}>⚠️</span>
            <span style={{ color: '#ff1744', fontSize: 11, fontWeight: 500 }}>
              Нельзя использовать такой запрос
            </span>
          </div>
          <div style={{ color: '#aaa', fontSize: 10, lineHeight: 1.5 }}>
            В приложении запрещены запросы связанные с:{' '}
            {getCategoryList().map((c, i, arr) => (
              <span key={c.name}>
                {c.emoji} {c.name}{i < arr.length - 1 ? ', ' : '.'}
              </span>
            ))}
          </div>
        </div>
      )}

      {error && !blocked && (
        <div className="mt-2" style={{ color: '#ff1744', fontSize: 10 }}>⚠ {error}</div>
      )}
      {!error && !blocked && (
        <div className="mt-2.5" style={{ color: '#666', fontSize: 10, lineHeight: 1.5 }}>
          Опиши на русском или английском — ИИ подберёт эмодзи. Примеры: «море и пальмы», «автомобиль», «подписка нетфликс».
        </div>
      )}
    </div>
  )
}
